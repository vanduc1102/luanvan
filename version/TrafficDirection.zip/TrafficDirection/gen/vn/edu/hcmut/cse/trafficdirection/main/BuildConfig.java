/** Automatically generated file. DO NOT MODIFY */
package vn.edu.hcmut.cse.trafficdirection.main;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}