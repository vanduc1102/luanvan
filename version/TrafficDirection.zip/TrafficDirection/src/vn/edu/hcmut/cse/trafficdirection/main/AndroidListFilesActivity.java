package vn.edu.hcmut.cse.trafficdirection.main;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import vn.edu.hcmut.cse.trafficdirection.main.R;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class AndroidListFilesActivity extends ListActivity {

	private String m_path = null;
	private List<String> fileList = new ArrayList<String>();
	private List<String> fileShowList = new ArrayList<String>();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.list_layout);

		Bundle extras = getIntent().getExtras();
		if (extras != null) {
			m_path = extras.getString("PATH");
		}

		File path = null;

		if (m_path != null)
			path = new File(Environment.getExternalStorageDirectory()
					.getAbsolutePath() + m_path);
		else
			path = new File(Environment.getExternalStorageDirectory()
					.getAbsolutePath());

		ListDir(path);

	}

	void ListDir(File f) {
		File[] files = f.listFiles();
		fileList.clear();
		fileShowList.clear();
		for (File file : files) {
			if (file.getName().endsWith("gpx")) {
				fileList.add(file.getPath());
				fileShowList.add(file.getName());
			}
		}

		ArrayAdapter<String> directoryList = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, fileShowList);
		setListAdapter(directoryList);
	}

	@Override
	protected void onListItemClick(ListView parent, View v, int position,
			long id) {
		SparseBooleanArray chosen = parent.getCheckedItemPositions();

		for (int i = 0; i < chosen.size(); i++) {
			if (chosen.valueAt(i)) {
				Intent it = new Intent(getApplicationContext(),
						MainActivity.class);
				Bundle extras = new Bundle();
				extras.putString("file", fileList.get(chosen.keyAt(i)));
				it.putExtras(extras);

				startActivity(it);
				break;
			}
		}
	}
}