package vn.edu.hcmut.cse.trafficdirection.overlay;

import java.util.ArrayList;

import vn.edu.hcmut.cse.trafficdirection.node.NodeGPS;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

public class GPXOverlay extends Overlay {

	private Projection project;
	private ArrayList<NodeGPS> data;
	private MapView mapView;

	public GPXOverlay(MapView m_MapView, ArrayList<NodeGPS> data) {
		// TODO Auto-generated constructor stub
		this.data = data;
		this.mapView = m_MapView;

		double startLat = data.get(0).lat;
		double startLon = data.get(0).lon;

		GeoPoint startPoint = new GeoPoint((int) (startLat * 1E6),
				(int) (startLon * 1E6));

		mapView.getController().animateTo(startPoint);
		mapView.getController().setZoom(17);

		project = mapView.getProjection();
	}

	public boolean draw(Canvas canvas, MapView mapView, boolean shadow,
			long when) {
		NodeGPS pre = null;
		NodeGPS cur = null;

		int step = 21 - mapView.getZoomLevel();

		for (int i = 0; i < data.size();) {
			cur = data.get(i);
			if (pre != null && cur != null) {
				if (pre == cur)
					break;

				double speed = (pre.speed + cur.speed) / 2.0;

				Paint mPaint = new Paint();

				mPaint.setAntiAlias(true);
				mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
				mPaint.setStrokeJoin(Paint.Join.ROUND);
				mPaint.setStrokeCap(Paint.Cap.ROUND);
				mPaint.setStrokeWidth(6);

				GeoPoint gp1 = new GeoPoint((int) (pre.lat * 1E6),
						(int) (pre.lon * 1E6));
				GeoPoint gp2 = new GeoPoint((int) (cur.lat * 1E6),
						(int) (cur.lon * 1E6));

				Point p1 = new Point();
				Point p2 = new Point();
				Path path = new Path();

				project.toPixels(gp1, p1);
				project.toPixels(gp2, p2);

				speed *= 3.6;

				int redColor = (int) ((1.0 - speed / 30.0) * 255);
				int greenColor = (int) ((speed / 30.0) * 255);

				mPaint.setColor(Color.argb(100, redColor, greenColor, 0));

				path.moveTo(p2.x, p2.y);
				path.lineTo(p1.x, p1.y);
				canvas.drawPath(path, mPaint);
			}
			pre = cur;

			i += step;
			if (i >= data.size())
				i = data.size() - 1;
		}
		return super.draw(canvas, mapView, shadow, when);

	}

}
